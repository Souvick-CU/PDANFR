import java.io.FileInputStream;
import java.io.FileWriter;
import java.lang.management.ManagementFactory;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.SystemOutLogger;
public class PPMCompression {

	public static String encode(char[] values)
	{
		StringBuffer rle = new StringBuffer();
		for(int i = 0; i<values.length; i++)
		{
			int runLength = 1;
			while(i+1 < values.length && values[i]==(values[i+1]))
			{
				runLength++;
				i++;
			}
			rle.append(runLength);
			rle.append(values[i]);
		}
		 return rle.toString();
	}
	public static String decode(String source) {
		int arrLength = 0;
		for(int i = 0; i<source.length(); i+=2) {
			int count = Character.getNumericValue(source.charAt(i));
			
			arrLength+=count;
		}
		char array[] = new char[arrLength];
		int k = 0;
		for(int i = 0; i<source.length(); i+=2)
		{
			int count = Character.getNumericValue(source.charAt(i));
			//System.out.println("count "+count+"\n");
			for(int j=0; j<count; j++)
			{
				array[j+k] = source.charAt(i+1);
				//System.out.print(source.charAt(i+1));
			}
			//System.out.println();
			k+=count;
		}
		String decoded = String.valueOf(array);
		return decoded;
	}
}