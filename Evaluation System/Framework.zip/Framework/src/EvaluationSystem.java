import java.io.FileInputStream;
import java.io.FileWriter;
import java.lang.management.ManagementFactory;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

public class EvaluationSystem {

	public static void main(String[] args) {
		try
		{
			FileWriter fw=new FileWriter("./result/lzdataset1.txt");
			//FileWriter fw1=new FileWriter("aes.txt");
			FileInputStream input = new FileInputStream("./result/dataset1.xls");
			
            POIFSFileSystem fs = new POIFSFileSystem( input );
            
            HSSFWorkbook wb = new HSSFWorkbook(fs);
         
            HSSFSheet sheet = wb.getSheetAt(0);
            //Row row;
           /* Cell cell2Update = sheet.getRow(1).getCell(2);
            cell2Update.setCellValue("Journalism");*/
            DataFormatter dataFormatter = new DataFormatter();
            Iterator<Row> rowIterator = sheet.rowIterator();
            double beforeTimeStamp = 0.00;
            beforeTimeStamp = ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            while (rowIterator.hasNext()) {
            	
                Row row = rowIterator.next();
                String rowval="";
                //System.out.println(row.toString());
                // Now let's iterate over the columns of the current row
                Iterator<Cell> cellIterator = row.cellIterator();

                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    String cellValue = dataFormatter.formatCellValue(cell);
                    rowval=rowval+" "+cellValue;
                    //long startTime = System.nanoTime();
                    //System.out.println(cellValue);
                    //CompressionDecompression.comdecom(cellValue);
//                    AES.mainfunc(cellValue);
                    //long endTime   = System.nanoTime();
            		//double totalTime = Double.valueOf((endTime - startTime)/1000);
            		//fw1.write(""+totalTime);
            		//fw1.write("\n");
                    
                    
                    //CompressionDecompression.comdecom(cellValue);
                    
            		//System.out.println(totalTime);
//            		fw.write(""+totalTime);
//            		fw.write("\n");
            		
                   // System.out.print(cellValue + "\t");
                }
                //System.out.println(rowval);
               // long startTime = System.nanoTime();
                
                //System.out.println(beforeTimeStamp);
                //String encr=AES.mainfunc(rowval);
                //double afterTimeStamp = ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
                //System.out.println("------------------------\n"+afterTimeStamp);
                
                //double cycleTime = afterTimeStamp - beforeTimeStamp;
                //System.out.println(encr);
                //long endTime   = System.nanoTime();
        		//double totalTime = Double.valueOf((endTime - startTime)/1000);
        		//fw.write(""+cycleTime);
        		//fw.write("\n");
        		
                 LZCompression lzc = new LZCompression();
                 lzc.comdecom(rowval);
                 ZIPCompression zc = new ZIPCompression();
                 zc.compress(rowval);
                 PPMCompression ppmc = new PPMCompression();
                 ppmc.encode(rowval.toCharArray());
//                 long endTime   = System.nanoTime();
//                 double totalTime = Double.valueOf((endTime - startTime)/1000);
//                 fw.write(""+totalTime);
//         		 fw.write("\n");
                 //System.out.println(totalTime);
                // CompressionDecompression.comdecom(encr);
                //System.out.println(compressedString);
                //String encr=AES.mainfunc(compressedString);
                //System.out.println(encr);
                //
            }
            
//            input.close();
//            FileOutputStream fos=new FileOutputStream("new.xls");
//            wb.write(fos);
//            fos.close();
             fw.close();
            
            
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}

	}

}
